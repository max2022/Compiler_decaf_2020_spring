-----Running Instructions-----

1) please run shell script exec.sh 
   run command: (bash exec.sh bad1.decaf)

2) I used gitbash for running shell script.

3) I also provided the screenshot.